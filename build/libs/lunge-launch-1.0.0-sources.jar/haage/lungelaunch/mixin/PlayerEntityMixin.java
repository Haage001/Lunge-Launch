package haage.lungelaunch.mixin;

import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin {
    
    @Inject(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"))
    private void onAttack(net.minecraft.class_1297 target, CallbackInfo ci) {
        // This mixin is kept for compatibility but the main logic is in the tick event
        // to ensure proper timing with the handSwinging detection
    }
}
