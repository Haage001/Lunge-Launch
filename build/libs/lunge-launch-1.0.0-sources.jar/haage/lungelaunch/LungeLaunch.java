package haage.lungelaunch;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LungeLaunch implements ModInitializer {
	public static final String MOD_ID = "lunge-launch";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	
	// Config: Delay in milliseconds before activating elytra after attack
	// Default is 0 (instant activation). Can be configured via ModMenu/Cloth Config
	public static int ACTIVATION_DELAY_MS = 0;

	@Override
	public void onInitialize() {
		LOGGER.info("Lunge Launch mod initialized!");
		
		// Register a ticker that checks for attacks every tick
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (class_3222 player : server.method_3760().method_14571()) {
				// Check if player is attacking (handSwinging means they just attacked)
				if (player.field_6252) {
					// Check if player is not on the ground
					if (player.method_24828()) {
						continue;
					}
					
					// Check if player has elytra equipped
					class_1799 chestStack = player.method_6118(class_1304.field_6174);
					if (!chestStack.method_31574(class_1802.field_8833)) {
						continue;
					}
					
					// Check if player is holding a spear
					class_1799 mainHandStack = player.method_6047();
					boolean isSpear = mainHandStack.method_31574(class_1802.field_63384) ||
					                  mainHandStack.method_31574(class_1802.field_63385) ||
					                  mainHandStack.method_31574(class_1802.field_63387) ||
					                  mainHandStack.method_31574(class_1802.field_63388) ||
					                  mainHandStack.method_31574(class_1802.field_63389) ||
					                  mainHandStack.method_31574(class_1802.field_63390) ||
					                  mainHandStack.method_31574(class_1802.field_63386);
					
					if (!isSpear) {
						continue;
					}
					
					// Check for Lunge enchantment (any level)
					class_9304 enchantments = mainHandStack.method_58695(class_9334.field_49633, class_9304.field_49385);
					int lungeLevel = enchantments.method_57536(player.method_56673()
						.method_30530(class_7924.field_41265)
						.method_46747(class_1893.field_63420));
					
					if (lungeLevel < 1) {
						continue;
					}
					
					// All conditions met - activate elytra with optional delay
					if (ACTIVATION_DELAY_MS > 0) {
						// Schedule delayed activation
						final class_3222 finalPlayer = player;
						new Thread(() -> {
							try {
								Thread.sleep(ACTIVATION_DELAY_MS);
								server.execute(() -> {
									((haage.lungelaunch.mixin.EntityAccessor) finalPlayer).invokeSetFlag(7, true);
								});
							} catch (InterruptedException e) {
								Thread.currentThread().interrupt();
							}
						}).start();
					} else {
						// Instant activation (default)
						((haage.lungelaunch.mixin.EntityAccessor) player).invokeSetFlag(7, true);
					}
				}
			}
		});
	}
}